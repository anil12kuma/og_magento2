<?php
namespace Mega\Phonelogin\Controller\Checkout;
use Magento\Framework\App\ResponseInterface;
use Magento\Framework\App\Action\Context;
class Sendcode extends  \Magento\Framework\App\Action\Action
{

    protected $resultJsonFactory;
    protected $_resourceConfig;
    protected $customer;

    /*
     *
     */
    public function __construct(
        Context $context,
        \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
        \Magento\Config\Model\ResourceModel\Config $resourceConfig,
        \Magento\Customer\Model\Session $customer
    ) {
        $this->resultJsonFactory  = $resultJsonFactory;
        $this->_resourceConfig = $resourceConfig;
        $this->customer = $customer;
        parent::__construct($context);
    }


    /**
     * Dispatch request
     *
     * @return \Magento\Framework\Controller\ResultInterface|ResponseInterface
     * @throws \Magento\Framework\Exception\NotFoundException
     */
    public function execute()
    {
        $this->customer->setData('mobile_verified', 0);
        $result = $this->resultJsonFactory->create();
        $respArray = [];
        $mobilePhone = $this->getRequest()->getParam('phone');
        if(isset($mobilePhone)){
            $customerPhone = $this->customer->getCustomer()->getMphoneNumber();
            if($customerPhone == $mobilePhone){
                $this->customer->setData('mobile_verified', 1);
                $respArray['status'] = false;
                return $result->setData($respArray);
            }
        	$helper = $this->_objectManager->create('Mega\Phonelogin\Helper\Data');
            $status = $helper->sendVerificationCode($mobilePhone);          
            if ($status['status']) {
                $creditCounts = $helper->getConfiguration('mega_phonelogin/api/available_credits');
                $remainingCount = $creditCounts -1;
                if($remainingCount > 0)
                    $this->_resourceConfig->saveConfig(
                        'mega_phonelogin/api/available_credits',
                        $creditCounts-1,
                        'default',
                        0
                );
                $respArray['status'] = true;
                $respArray['message'] = __('A Verification code has been sent on your mobile number');
                $this->messageManager
                         ->addSuccessMessage(__('A Verification code has been sent on your mobile number'));
            } else {
                $respArray['status'] = false;
                $respArray['message'] = __('An Error occurred sending the verification code');
                $this->messageManager->addErrorMessage(__('An Error occurred sending the verification code'));
            }
            return $result->setData($respArray);
        }
        $respArray['status'] = false;
        $respArray['message'] = __('Error occurred sending the verification code');
        $this->messageManager->addErrorMessage(__('An Error occurred sending the verification code'));
        return $result->setData($respArray);
    }
}
