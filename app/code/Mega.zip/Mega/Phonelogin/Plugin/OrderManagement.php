<?php 
declare(strict_types=1);
namespace Mega\Phonelogin\Plugin;

use Magento\Sales\Api\Data\OrderInterface;
use Magento\Sales\Api\OrderManagementInterface;
use Magento\Customer\Api\AddressRepositoryInterface;
use Magento\Quote\Model\ShippingMethodManagement;
use Magento\Customer\Model\Session;


class OrderManagement
{

	protected $addressRepository;
    protected $layoutFactory;
    protected $_session;

    public function __construct(
        AddressRepositoryInterface $addressRepository,
        Session $session,
        \Magento\Framework\View\LayoutFactory $layoutFactory
    ) {
        $this->addressRepository = $addressRepository;
        $this->_session = $session;
        $this->layoutFactory = $layoutFactory;
    }

  
    public function beforePlace(
        OrderManagementInterface $subject,
        OrderInterface $order
    ): array {
        $quoteId = $order->getQuoteId();
        $isValid = $this->_session->getData('mobile_verified');
        if(!$isValid){
        	throw new \Magento\Framework\Exception\LocalizedException (__("Please Verify Your Mobile Number."));
        }
        return [$order];
    }
}
