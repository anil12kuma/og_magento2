<?php
namespace Magetop\ReviewManagement\Controller\Adminhtml\ReviewManagement;

class Delete extends \Magetop\ReviewManagement\Controller\Adminhtml\ReviewManagement
{

}