<?php
namespace Magetop\ReviewManagement\Controller\Adminhtml\ReviewManagement;

class Edit extends \Magetop\ReviewManagement\Controller\Adminhtml\ReviewManagement
{

}