<?php
namespace Magetop\ReviewManagement\Controller\Adminhtml\ReviewManagement;

class NewAction extends \Magetop\ReviewManagement\Controller\Adminhtml\ReviewManagement
{

}