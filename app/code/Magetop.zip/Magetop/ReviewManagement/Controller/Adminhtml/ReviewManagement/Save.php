<?php
namespace Magetop\ReviewManagement\Controller\Adminhtml\ReviewManagement;

class Save extends \Magetop\ReviewManagement\Controller\Adminhtml\ReviewManagement
{

}