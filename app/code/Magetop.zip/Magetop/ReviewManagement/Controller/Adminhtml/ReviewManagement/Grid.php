<?php
namespace Magetop\ReviewManagement\Controller\Adminhtml\ReviewManagement;

class Grid extends \Magetop\ReviewManagement\Controller\Adminhtml\ReviewManagement
{

}