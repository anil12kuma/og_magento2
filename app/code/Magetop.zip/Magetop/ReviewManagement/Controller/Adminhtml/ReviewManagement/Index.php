<?php
namespace Magetop\ReviewManagement\Controller\Adminhtml\ReviewManagement;

class Index extends \Magetop\ReviewManagement\Controller\Adminhtml\ReviewManagement
{

}