<?php
namespace Magetop\ReviewManagement\Controller\Adminhtml\ReviewManagement;

class MassStatus extends \Magetop\ReviewManagement\Controller\Adminhtml\ReviewManagement
{

}