# Lof All Extension

The extension was included on all landofcoder extensions to generate admin menu 

## 1. Documentation

## 2. How to install All Extension

### Install via composer (recommend)

Run the following command in Magento 2 root folder:

```
composer require landofcoder/module-all
php bin/magento setup:upgrade
php bin/magento setup:static-content:deploy
```
