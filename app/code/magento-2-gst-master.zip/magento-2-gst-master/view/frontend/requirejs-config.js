var config = {
    map: {
        '*': {
            'Magento_Checkout/js/view/billing-address':
                'Codilar_Gst/js/view/billing-address'
        }
    }
};