<?php 
declare(strict_types=1);
namespace Mega\Phonelogin\Plugin;

use Magento\Sales\Api\Data\OrderInterface;
use Magento\Sales\Api\OrderManagementInterface;
use Magento\Customer\Api\AddressRepositoryInterface;
use Magento\Quote\Model\ShippingMethodManagement;
use Magento\Customer\Model\Session;
use Mega\Phonelogin\Helper\CustomerHelper;


class OrderManagement
{

	protected $addressRepository;
    protected $layoutFactory;
    protected $_customerHelper;
    protected $_session;

    public function __construct(
        AddressRepositoryInterface $addressRepository,
        Session $session,
        CustomerHelper $customerHelper,
        \Magento\Framework\View\LayoutFactory $layoutFactory
    ) {
        $this->addressRepository = $addressRepository;
        $this->_session = $session;
        $this->layoutFactory = $layoutFactory;
    }

  
    public function beforePlace(
        OrderManagementInterface $subject,
        OrderInterface $order
    ): array {
        $quoteId = $order->getQuoteId();
        $addressId = $order->getShippingAddress()->getData('customer_address_id');
        $isValid = $this->_session->getData('mobile_verified');
        if(!$isValid){
        	throw new \Magento\Framework\Exception\LocalizedException (__("Please Verify Your Mobile Number before order place."));
        }
        if($addressId){
            $address = $this->addressRepository->getById($addressId);
            $address->setCustomAttribute('is_mobile_verified', 1); 
            $this->addressRepository->save($address);
        }
        $this->_session->setData('mobile_verified', 0);
        $this->_session->setData('mobile_verified_oncheckout', 0);
        return [$order];
    }
}
