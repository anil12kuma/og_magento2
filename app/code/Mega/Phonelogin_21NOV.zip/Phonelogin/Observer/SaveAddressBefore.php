<?php

namespace Mega\Phonelogin\Observer;

use Magento\Customer\Model\Session;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;

class SaveAddressBefore implements ObserverInterface
{

    /**
     * @var Session
     */
    private $_userSession;

    public function __construct(
        Session $session
    )
    {
        $this->_userSession = $session;
    }


    public function execute(Observer $observer)
    {
        $writer = new \Zend_Log_Writer_Stream(BP . '/var/log/otp_log.log');
        $logger = new \Zend_Log();
        $logger->addWriter($writer);

        $d = $this->_userSession->getData('mobile_verified');
        $logger->info('value '.$d);
    }
}
