Magento 2 customer login by Mobile number and OTP verification
An extension developed by Codeinnovers that allows store customers to
login to their account using their registered Mobile NUmber

========================Steps To Install==================
1. Extract the extension to directory Mega_Phonelogin
2. run following commands
	php bin/magento setup:upgrade
	php bin/magento setup:static-content:deploy 
3. clear cache


For any query feel free to connect with us:
skype: live:samparker801
email: samparker801@gmail.com

