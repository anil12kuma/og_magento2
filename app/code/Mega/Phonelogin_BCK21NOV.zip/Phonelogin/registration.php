<?php
/**
 * Module configuration
 */
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Mega_Phonelogin',
    __DIR__
);
