<?php

namespace Mega\Phonelogin\Plugin;

use Magento\Checkout\Api\Data\PaymentDetailsInterface;
use Magento\Checkout\Api\Data\ShippingInformationInterface;
use Magento\Checkout\Model\ShippingInformationManagement;
use Magento\Framework\Exception\InputException;
use Magento\Framework\Exception\LocalizedException;

class ValidateAddressPlace
{
    protected $_coreSession;

    protected $_logger;
    protected $customer;

    public function __construct(
        \Magento\Framework\Session\SessionManagerInterface $coreSession,
        \Magento\Customer\Model\Session $customer,
        \Psr\Log\LoggerInterface $logger
    ) {
        $this->_coreSession = $coreSession;
        $this->customer = $customer;
        $this->_logger = $logger;
    }

    /**
     * @param ShippingInformationManagement $subject
     * @param $cartId
     * @param ShippingInformationInterface $addressInformation
     * @return array
     * @throws InputException
     */
    public function beforeSaveAddressInformation(ShippingInformationManagement $subject, $cartId, ShippingInformationInterface $addressInformation): array
    {
        $address = $addressInformation->getShippingAddress();
        $addressPhone = $address->getTelephone();
        $customerPhone = $this->customer->getCustomer()->getMphoneNumber();
        if($customerPhone != $addressPhone){
        	 $this->customer->setData('mobile_verified', 0);
        	 throw new InputException(__("Please Verify Your Mobile Number."));
        }
        $this->customer->setData('mobile_verified', 1);
        return [$cartId, $addressInformation];
    }

}

