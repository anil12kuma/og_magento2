<?php
/**
 * Created by PhpStorm.
 * User: simplysaif
 * Date: 28/4/18
 * Time: 1:03 PM
 */

namespace Mega\Phonelogin\Helper;


class Messages extends  \Magento\Framework\App\Helper\AbstractHelper
{

}