<?php

namespace Mguru\OtpController\Controller\Otp;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;

class SendOtp extends Action
{ 
    protected $_customerSession;

    public function __construct(
        Context $context,
        \Magento\Customer\Model\Session $customerSession
    ) {
        parent::__construct($context);
        $this->_customerSession = $customerSession;
    }

    public function execute()
    {   
        $otp = rand(999,9999);
        $this->_customerSession->setOTP($otp); // set otp to customer session
        $getOTP = $this->_customerSession->getOTP(); // get otp from customer session
        $post = $this->getRequest()->getParams();
        $mobile = $post['mobile'];

        //$msg = "$otp is the OTP for your mobile verification";
        //$msg = "$otp is the Verification OTP for your transaction at Columbia Sportswear. This OTP is valid for the next 10 minutes. DO NOT share the OTP with anyone else.";
        $msg = "$otp is the verification OTP for your Login at Columbia Sportswear. This OTP is valid for the next 10 minutes. DO NOT share the OTP with anyone else.";
        
        //$path='http://sms.valueleaf.com​/sms/user/urlsms.php?username=ChogoriOTP&pass=nC@3a5!S&senderid=COLUMB&dest_mobileno='.$mobile.'&message='.urlencode($msg).'&response=Y';
        $path = 'http://sms.valueleaf.com/sms/user/urlsms.php?username=ChogoriOTP&pass=nC@3a5!S&senderid=COLUMB&dest_mobileno='.$mobile.'&message='.urlencode($msg).'&response=Y';

        //echo $path;

        $ch = curl_init($path);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
        $response = curl_exec($ch);
        curl_close($ch);
        echo $response;

        // $curl = curl_init();
        // curl_setopt_array($curl, array(
        //   CURLOPT_URL => $path,
        //   CURLOPT_RETURNTRANSFER => true,
        //   CURLOPT_ENCODING => "",
        //   CURLOPT_MAXREDIRS => 10,
        //   CURLOPT_TIMEOUT => 0,
        //   CURLOPT_FOLLOWLOCATION => true,
        //   CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        //   CURLOPT_CUSTOMREQUEST => "POST",
        // ));
        // $response = curl_exec($curl);
        // curl_close($curl);
        // echo $response;
    }

}