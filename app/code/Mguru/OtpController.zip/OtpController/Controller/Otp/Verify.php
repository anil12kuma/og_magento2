<?php

namespace Mguru\OtpController\Controller\Otp;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;

class Verify extends Action
{ 
    protected $_customerSession;

    public function __construct(
        Context $context,
        \Magento\Customer\Model\Session $customerSession
    ) {
        parent::__construct($context);
        $this->_customerSession = $customerSession;
    }

    public function execute()
    {   
        $getOTP = $this->_customerSession->getOTP(); //get otp from customer session
        $post = $this->getRequest()->getParams();
        $opt = $post['otp'];
        if($getOTP == $opt){    // match customer session to input session
            $response = array();
            $data =  $this->getRequest()->getParams();
            $response['message'] = "otp verification successful";
            $response['code'] = "success";
            $this->_customerSession->unsOTP(); // unset customer session otp
            echo json_encode($response);
        }
        else{
            $response['message'] = "otp verification failed";
            $response['code'] = "failed";
            $this->_customerSession->unsOTP();
            echo json_encode($response);
        }
    }

}