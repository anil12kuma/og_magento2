<?php
/**
 * Copyright © 2016 Magetop. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Mguru\AjaxCartPro\Block;
class AjaxCart extends \Magento\Framework\View\Element\Template
{
	public function __construct(
		\Magento\Framework\View\Element\Template\Context $context,
		array $data = []
	){	
		 parent::__construct($context, $data);
	}
	
	
	
}